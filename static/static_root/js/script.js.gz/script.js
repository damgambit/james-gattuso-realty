jQuery(document).ready(function(){

	// Toggle Mail Menu
	jQuery('.mobile_icon').on('click', function(){
	    jQuery('.main_menu').slideToggle();    
	});


});